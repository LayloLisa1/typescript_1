import { expect } from 'chai';
import UserService from '../services/UserService';
import User from '../models/User';
import sequelize from '../models/index';

describe('UserService', () => {
  before(async () => {
    await sequelize.sync({ force: true });
  });

  afterEach(async () => {
    await User.destroy({ where: {} });
  });

  it('should create a new user', async () => {
    const user = await UserService.createUser({
      username: 'testuser',
      email: 'test@example.com',
      password: 'password123',
    });

    expect(user).to.have.property('user_id');
    expect(user.username).to.equal('testuser');
    expect(user.email).to.equal('test@example.com');
  });

  it('should get a user by ID', async () => {
    const newUser = await UserService.createUser({
      username: 'testuser',
      email: 'test@example.com',
      password: 'password123',
    });

    const user = await UserService.getUserById(newUser.user_id);
    expect(user).to.not.be.null;
    if (user) {
      expect(user.username).to.equal('testuser');
      expect(user.email).to.equal('test@example.com');
    }
  });

  it('should update a user', async () => {
    const newUser = await UserService.createUser({
      username: 'testuser',
      email: 'test@example.com',
      password: 'password123',
    });

    const [numOfAffectedRows, updatedUsers] = await UserService.updateUser(newUser.user_id, { username: 'updateduser' });
    expect(numOfAffectedRows).to.equal(1);

    const updatedUser = updatedUsers[0];
    expect(updatedUser.username).to.equal('updateduser');
  });

  it('should delete a user', async () => {
    const newUser = await UserService.createUser({
      username: 'testuser',
      email: 'test@example.com',
      password: 'password123',
    });

    await UserService.deleteUser(newUser.user_id);

    const user = await UserService.getUserById(newUser.user_id);
    expect(user).to.be.null;
  });
});
