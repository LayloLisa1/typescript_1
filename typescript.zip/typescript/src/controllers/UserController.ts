import { Request, Response } from 'express';
import UserService from '../services/UserService';

class UserController {
  public async createUser(req: Request, res: Response): Promise<void> {
    const user = await UserService.createUser(req.body);
    res.status(201).json(user);
  }

  public async getUserById(req: Request, res: Response): Promise<void> {
    const user = await UserService.getUserById(parseInt(req.params.user_id, 10));
    if (user) {
      res.status(200).json(user);
    } else {
      res.status(404).json({ message: 'User not found' });
    }
  }

  public async updateUser(req: Request, res: Response): Promise<void> {
    const [numOfAffectedRows, updatedUsers] = await UserService.updateUser(parseInt(req.params.user_id, 10), req.body);
    if (numOfAffectedRows === 1) {
      res.status(200).json(updatedUsers[0]);
    } else {
      res.status(404).json({ message: 'User not found' });
    }
  }

  public async deleteUser(req: Request, res: Response): Promise<void> {
    await UserService.deleteUser(parseInt(req.params.user_id, 10));
    res.status(204).send();
  }
}

export default new UserController();
