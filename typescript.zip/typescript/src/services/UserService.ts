import User from '../models/User';

class UserService {
  public async createUser(data: any): Promise<User> {
    return await User.create(data);
  }

  public async getUserById(user_id: number): Promise<User | null> {
    return await User.findByPk(user_id);
  }

  public async updateUser(user_id: number, data: any): Promise<[number, User[]]> {
    return await User.update(data, {
      where: { user_id },
      returning: true,
    });
  }

  public async deleteUser(user_id: number): Promise<void> {
    await User.destroy({
      where: { user_id },
    });
  }
}

export default new UserService();
